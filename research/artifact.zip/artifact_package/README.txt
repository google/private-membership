Run ./install.sh to install the entire artifact and relevant projects.
Then, follow the instructions in each claim subdirectory to build and run the code for that claim.