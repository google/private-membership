cd artifact
./install.sh