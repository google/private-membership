In the `artifact/evaluation` directory, run the following commands to generate the results that support claim (C3).

```
./run-application-experiments.sh
```

